/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio8;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author SALA H
 */
public class Metodos {

    Nodo head;
    Nodo head2;
    // Nodo tail2;
    int cont;
    Scanner entrada;

    public Metodos() {
        this.head = null;
        this.head2 = null;
        this.entrada = new Scanner(System.in);
        this.cont = 0;
    }

    public int menu (){
        System.out.println("\nInsertar            [1]: ");
        System.out.println("Recorrer            [2]: ");
        System.out.println("Recorrer lista dos  [3]: ");
        System.out.println("Salir               [0]:");
        return entrada.nextInt();         
    }
    
    public boolean listaVacia(Nodo aux) {
        return (aux == null);
    }

    public void insertar() {
        int num;
        System.out.println("Ingrese un número:");
        num = entrada.nextInt();
        Nodo nuevo = new Nodo(num);
        if (listaVacia(head)) {
            head = nuevo;
        } else {
            Nodo actual = head;

            while (actual.sig != null) {
                actual = actual.sig;
            }
            actual.sig = nuevo;
            cont++;
        }
    }

    public void recorrer(Nodo aux) {
        Nodo actual = aux;
        while (actual != null) {
            System.out.print(actual.dato + " -> ");
            actual = actual.sig;
        }
    }
    
    /*
    public void recorrer(Nodo aux) {
        Nodo actual = aux;
        if (listaVacia(head)) {
            System.err.println("Lista vacía");
        } else {
            while (actual != null) {
                System.out.print(actual.dato + " -> ");
                actual = actual.sig;
            }
        }        
    }
    */
    
    public boolean numMayor(int num, int dato) {
        return (num>dato);
    }

    public Nodo numLimite() {        
        System.out.println("Ingrese el número límite:");
        int lim = entrada.nextInt();
        
        if (listaVacia(head)) {
            System.out.println("No hay como crear la segunda lista:");
        } else {
            Nodo actual = head;              
            Nodo actual2 = head2;
            
            while (actual != null) {
                if (numMayor(lim, actual.dato)) {
                    if (listaVacia(head2)) {
                        head2 = actual;
                        actual2 = head2.sig;
                    }
                    actual2 = actual;
                    actual2 = actual2.sig;
                }
                actual = actual.sig;
            }
        }
        return head2;
    }

    /*public void eliminar() {
        int lim;
        System.out.print("Ingrese limite: ");
        lim = entrada.nextInt();
        Nodo nuevo = new Nodo(lim);
        if (listaVacia(head)) {
            head = nuevo;
        } else {
            if (lim == head.dato) {
                if (head.sig == null) {
                    tail = null;
                }
                head = head.sig;
            } else {
                Nodo actual = head;
                while (actual.sig != null && actual.sig.dato != lim) {
                    actual = actual.sig;
                }
                if (actual.sig == tail) {
                    tail = actual;
                }
                if (actual.sig != null) {
                    actual.sig = actual.sig.sig;
                } else {
                    System.out.println("No está :(");
                }

            }
        }
    }*/
}
